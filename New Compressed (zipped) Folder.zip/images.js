console.log('images loaded');
vaccineZom=new Image;vaccineZom.src="images/wheatfield_zombies2.jpg";
disClose=new Image;disClose.src="images/disneylandClosing2.jpg";
tuckerberg=new Image;tuckerberg.src="images/mariontuckerberg.jpg"

let vacZom={name:'vacZom',img:vaccineZom,width:canv.width-20,height:canv.height-20,x:10,y:10,headline:'Vaccine Causes Zombie Event'};
let dClosed={name:'disneyClosed',img:disClose,width:canv.width-20,height:canv.height-20,x:10,y:10,headline:'The Scariest place on Earth'};
let mTuck={name:'Marion Tuckerberg',img:tuckerberg,width:canv.width-20,height:canv.height-20,x:10,y:10,headline:'Instaface Suspends President'};

const slides=[vacZom,dClosed,mTuck]

fauxLogo=new Image();fauxLogo.src='images/faux-Logo.png';
let fLogo={name:'Faux Logo',width:120,height:120,x:600,y:330,img:fauxLogo};

const allItems=[fLogo];
